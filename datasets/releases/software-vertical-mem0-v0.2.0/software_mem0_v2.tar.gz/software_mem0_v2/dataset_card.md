# Software Mem0 qualification vertical v0.2.0

- schema version: `2`
- generator version: `software-project-mem0-vertical-0.2`
- release: `software-vertical-mem0-v0.2.0`
- episodes: `1`
- sessions per episode: `16`
- semantic seeds: `[42]`

Public policy surfaces and evaluator gold are stored in separate trees. The release is generated without model or memory-backend calls.
