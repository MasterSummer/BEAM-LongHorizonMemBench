# Software Project state-first vertical slice

- schema version: `1`
- generator version: `software-project-vertical-0.1`
- episodes: `1`
- sessions per episode: `16`
- semantic seeds: `[42]`

This offline exemplar is a frozen benchmark artifact; no live memory backend or model call is used.
